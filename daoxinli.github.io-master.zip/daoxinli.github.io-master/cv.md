---
layout: default
title: CV
slug: /cv
---

Please click [here](assets/li_CV.pdf) to view my academic CV (last updated: Nov 2022).

<br />
<br />
