---
layout: default
title: Teaching
slug: /teaching
---

## Teaching

**Fall 2021**: Teaching Assistant for *LING300 Tutorial in Linguistics*, Penn (Instructor: <a href="https://www.ling.upenn.edu/~jlegate/">Julie Anne Legate</a>)

**Spring 2021**: Teaching Assistant for *LING001 Introduction to Linguistics*, Penn (Instructor: <a href="https://www.martinsalzmann.com">Martin Salzmann</a>)

**Fall 2020**: Teaching Assistant for *LING270 Language Acquisition*, Penn (Instructor: <a href="https://www.ling.upenn.edu/~ycharles/">Charles Yang</a>)


<br />
<br />
